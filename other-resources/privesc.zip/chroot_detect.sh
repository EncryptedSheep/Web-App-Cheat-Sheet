#!/bin/bash
if [ "$(stat -c %d:%i /)" != "$(stat -c %d:%i /proc/1/root/.)" ]; then
  echo " [!] Chroot detected"
else
  echo " [-] No chroot"
fi
